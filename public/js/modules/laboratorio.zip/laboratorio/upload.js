// JavaScript Document
$(document).ready(function(){
	
	var $body =  $("body");
	var base_url = $("#base_url").attr("class");
	
	
	
	
	
	
});	