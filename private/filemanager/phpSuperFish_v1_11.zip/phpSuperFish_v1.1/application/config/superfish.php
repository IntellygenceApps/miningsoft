<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
//this is your custom css
//I've tried to make it easy to change themes colors and it mostly works ok
//out of the box - but if you dont want to use it point this to the css file you
//want to use.
//note it MUST live in /assets/theme
// if you do want to tinker with the theme I would suggest copying 
// assets/superfish/css/superfish.css into the theme folder:
// assets/superfish/theme and the setting 
//$config['superfish_css']	= 'superfish.css';
$config['superfish_css']	= 'superfish_css.php';


