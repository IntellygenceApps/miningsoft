<?php
/**
 * PHP superfish css
 *
 * A component of a Codeigniter library that creates a superfish menu automatically with just few lines of code.
 *
 * Copyright (C) 2013  E.z 
 *
 * LICENSE
 *
 * PHP Superfish css is released with dual licensing, using the GPL v3 (license-gpl3.txt) and the MIT license (license-mit.txt).
 * You don't have to do anything special to choose one license or the other and you don't have to notify anyone which license you are using.
 * Please see the corresponding license file for details of these licenses.
 * You are free to use, modify and distribute this software, but all copyright information must remain.
 *
 * @package    	PHP Superfish
 * @license    	As Above
 */
define('DEBUG',True); 
// Tell the browser that this is CSS instead of HTML
header("Content-type: text/css");

// Get the color generating code
include_once("csscolor.php");

//set our exception handler - so errors are displayed in the css
set_exception_handler('exception_handler');
function exception_handler($err) {
    echo("/* ERROR " . $err->getMessage() . " */\n");
}

// Define the basis of our color palette
$background=isset($_GET['b']) ? $_GET['b'] : 'BDD2FF';
$highlight =isset($_GET['h']) ? $_GET['h'] : '0099FF';
$fontcolor =isset($_GET['c']) ? $_GET['c'] : '5473AA';

$cachefile="superfish_css.{$background}{$fontcolor}{$highlight}.css";
$done=False;
if (!DEBUG and file_exists($cachefile)){
	$cssfile = file_get_contents($cachefile);
	if ($cssfile !== False){
		echo  "/* Using Cached file : {$cachefile} */\n" ;
		echo $cssfile ;
		$done=True;
	}
}
if ($done === False ) {
	$base = new CSS_Color($background);
	$high = new CSS_Color($highlight);

	$color_map = array( '#dFeEFF'=>'#dFeEFF',  			 // fallback for border-top when RGBa is not supported
						'#1133AA'=>'#'.$fontcolor,  	 //.sf-menu font color : #BDD2FF;
						'#BDD2FF'=>'#'.$background,		 //.sf-menu li  background : background: #BDD2FF;
						'#AABDE6'=>'#'.$base->bg['+2'] , //.sf-menu ul li background: #AABDE6;
						'#9AAEDB'=>'#'.$base->bg['+3'],  //.sf-menu ul ul li background: #9AAEDB;
						'#CFDEFF'=>'#'.$highlight,   	 //Hover background: #CFDEFF;
						'#D1DFFF'=>'#'.$high->bg['+2'],  //Navbar Hover level 2 background: #D1DFFF;
						'#E6EEFF'=>'#'.$high->bg['+3']); //Navbar Hover level 3 background: #E6EEFF;

	$css_theme='

.sf-menu, .sf-menu a , 
.sf-menu a:visited, 
.sf-menu a:hover{
	color: #1133AA;
}

.sf-menu li {
	background: #BDD2FF;
}
.sf-menu ul li {
	background: #AABDE6;
}
.sf-menu ul ul li {
	background: #9AAEDB;
}
.sf-menu li:hover,
.sf-menu li.sfHover {
	background: #CFDEFF;
}

.sf-navbar {
	background: #BDD2FF;
	position: relative;
	margin-bottom: 5em;
}
/* provide background colour for submenu strip */
/* you should just set the menu\'s container bg colour rather than use pseudo-elements */

.sf-navbar:before {
	background: #BDD2FF;
}

.sf-navbar ul {
	box-shadow: none;
}
.sf-navbar li {
	background: #AABDE6;
}
.sf-navbar ul li {
	background: #BDD2FF;
}
.sf-navbar li.current {
	background: #BDD2FF;
}
.sf-navbar li:hover,
.sf-navbar li.sfHover,
.sf-navbar ul li.current {
	background: #BDD2FF;
}
.sf-navbar ul li:hover,
.sf-navbar ul li.sfHover,
.sf-navbar ul ul li {
	background: #D1DFFF;
}
.sf-navbar ul ul li:hover,
.sf-navbar ul ul li.sfHover,
.sf-navbar ul ul li.current {
	background: #E6EEFF;
}

/* border tweaks I found I needed */
.sf-menu {
	margin-bottom:0px;
}

.sf-navbar {
	margin-bottom: 0em;
}
.sf-menu a {
	border:0;
	
	
';
	echo "/* Generated new theme file */\n";
	$header="/* Mapped the following colors \n";
	foreach($color_map as $old => $new){
		$new=strtoupper($new);
		$header.= "\t$old => $new\n";
		$css_theme=str_ireplace($old , $new, $css_theme);
	}
	$header.="*/\n";
	$css_theme=$header.$css_theme;
	file_put_contents($cachefile,$css_theme);
	echo $css_theme;
	
	
	}
?>